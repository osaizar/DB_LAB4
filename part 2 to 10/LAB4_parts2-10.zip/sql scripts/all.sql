-- Run this script to setup all the database.
-- Authors: Juan Ramon del Cano & Oier Saizar

drop database lab4;
create database lab4;
use lab4;

source part2.sql
source part3.sql
source part3.sql
source part4.sql
source part5.sql
source part6.sql
source part7.sql
source part10.sql --this one is optional, it only adds a delay to make overbookings possible
